**Step 1:** [Download](https://github.com/thepranaygupta/html-tailwind-css-starter-pack/archive/refs/heads/main.zip) this repo as a zip

**Step 2:** To run:

```bash
npm install
npm run start
```

**Step 3:** Goto [http://localhost:5173](http://localhost:5173)

Facing any issue: [Documentation](https://tailwindcss.com/docs/installation/using-postcss)
